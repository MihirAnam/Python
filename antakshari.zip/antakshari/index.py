import os
import gtts #pip install gTTS in cmd
from playsound import playsound #pip install playsound in cmd
from googletrans import Translator #pip install googletrans==3.1.0a0

print("Antakshari Song Guesser")
print("Enter the starting alphabet of song you want")

exist=''
l1=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']

l2=['J', 'K', 'L', 'M', 'N', 'O', 'P']

l3=['Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']

def check(content="",count=""):
    user=input("\n Enter Alphabet ")
    user=user.upper()
    if user in l1:
        with open("songs.txt",'r') as file:
            if count!='l1':
                content=file.readlines()
                songs(content,user)
            elif count=='l1':
                songs(content,user)
            
        
        

    elif user in l2:
        with open("songs1.txt",'r') as file:
            if count!='l2':
                content=file.readlines()
                songs(content,user)
            elif count=='l2':
                songs(content,user)
            

    elif user in l3:
        with open("songs2.txt",'r') as file:
            if count!='l3':
                content=file.readlines()
                songs(content,user)
            elif count=='l3':
                songs(content,user)



def songs(content,user):
    
    for i in content:
        for j in range(1,len(content)):
        
            if i.startswith(user):
                print(i)
                translator = Translator()
                i1 = translator.translate(i, src='en', dest='hi')
                print(i1.text)

                file = "sound.mp3"
                tts = gtts.gTTS(text=i1.text,lang='hi')
                tts.save(file) 
                playsound(file)
                os.remove(file)
                content.pop(content.index(i))
                if user in l1:
                    count='l1'
                    check(content,count)
                elif user in l2:
                    count='l2'
                    check(content,count)
                elif user in l3:
                    count='l3'  
                    check(content,count)

            else:
                exist="not"

    if exist=="not":
        print("No more results for this")
        check(content)

check()



