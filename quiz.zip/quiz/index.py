import random
print("कौन बनेगा करोड़पति \n")
name=input('Enter Your Name: ')
print(f'\n{name.capitalize()} जी नमस्ते स्वागत है आपका कौन बनेगा करोड़पति माई')
print("पायथन स्पेशल माई आपका स्वागत है \n")
file=open('quiz.txt','r')
content=file.readlines()
score=0
l1=''
l2=''
for i in range(1,11):
    
    if i==1:
        print("पहलाा प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 5000 रुपये के लिए")
    elif i==2:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 10000 रुपये के लिए")
    elif i==3:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 50000 रुपये के लिए")
    elif i==4:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 100000 रुपये के लिए")
    elif i==5:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 300000 रुपये के लिए")
    elif i==6:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 700000 रुपये के लिए")
    elif i==7:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 1500000 रुपये के लिए")
    elif i==8:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 300000 रुपये के लिए")
    elif i==9:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 5000000 रुपये के लिए")
    elif i==10:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 1 करोड़ रुपये के लिए")
    elif i==10:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा 7 करोड़ रुपये के लिए")
    else:
        print("अगला प्रश्न आपकी कंप्यूटर स्क्रीन पर ये रहा")
    for j in content[0:6]:
        if j.startswith('A')==False:
            print(j)
        elif j.startswith('A'):
            split=j.split(':')
            temp=split[1]
        content.remove(j)
    print("lifelines:- \n 1.Audience Pole \n 2.Expert Opinion \n Enter Options a/b/c/d \n")

    def lifeline():
        global l1
        global l2
        lifeline.user=input("Enter: ")

        if lifeline.user=='1':
            if l1=='auidence':
                print("Auidence Pole is Already Taken")
                lifeline()
            else:
                print(f"{random.randint(51,100)}% Audience says: {temp}")
                l1='auidence'
                lifeline()
                
        elif lifeline.user=='2':
            if l2=='expert':
                print("Expert Opinion is Already Taken")
                lifeline()
            else:
                print(f"Expert says: {temp}")
                l2='expert'
                lifeline()
                
        else:
            print("No lifeline used")


    lifeline()     
    
    if lifeline.user==temp.rstrip():
        print("\n \u2713 सही जवाब \n \n")
        score=score+1
    elif lifeline.user!=temp:
        print(" \u2717 गलत जवाब")
        break
    else:
        print("invalid input")
        

print(f"Total Questions Attempted={score}")

if score==0:
    print("ओओओ अफ़सोस आप कुछ नहीं जीत पाए")
elif score==1:
    print("मुबारको आप यहां से 5000 रुपये ले जा रहे हैं")
elif score==2:
    print("मुबारको आप यहां से 10000 रुपये ले जा रहे हैं")
elif score==3:
    print("मुबारको आप यहां से 50000 रुपये ले जा रहे हैं")
elif score==4:
    print("मुबारको आप यहां से 100000 रुपये ले जा रहे हैं")
elif score==5:
    print("मुबारको आप यहां से 700000 रुपये ले जा रहे हैं")
elif score==6:
    print("मुबारको आप यहां से 1500000 रुपये ले जा रहे हैं")
elif score==7:
    print("मुबारको आप यहां से 3000000 रुपये ले जा रहे हैं")
elif score==8:
    print("मुबारको आप यहां से 5000000 रुपये ले जा रहे हैं")
elif score==9:
    print("मुबारको आप यहां से 1 करोड़ रुपये ले जा रहे हैं")
elif score==10:
    print("मुबारको एपी जीत चुके हो 7 करोड़")

        
    

        
            

        
        
