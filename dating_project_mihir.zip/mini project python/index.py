logo="find.love"
greet="\u2764\ufe0fWelcome To find.love  \u2764\ufe0f"
print("\u2764\ufe0f"+logo.center(50)+"\u2764\ufe0f"+"\n")
print(greet.center(55)+"\n")
def reg():
    regstatus=input("Type 'register' if you are not registered else 'login' :")
    print()
    #registeration
    if regstatus=='register':
        print("enter registration details:-")
        rname=input("Enter your name to register :")
        rage=int(input("Enter your Age :"))
        rgender=input("Enter your gender m/f :")
        
        def checkphone():
            phone=int(input("Enter your phone no :"))
            checkphone.phone=phone
            f = open("register.txt", "r")
            for i in f.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]

                if d['phone_no']==str(phone):
                    print("phone no already exist")
                    checkphone()
                    
                    

            if len(str(phone))<10 or len(str(phone))>10:
                print("**Invalid phone no**")
                print()
                checkphone()
                
            
            
        checkphone()
        phone=checkphone.phone
        password=input("Enter Password :")
        print()
        file=open('register.txt','a')
        details="name:"+rname + " " +"age:" +str(rage) + " " +"gender:" + rgender + " " + "phone_no:" + str(phone) + " "+ "Password:" + password + "\n"
        content=file.write(details)
        name=rname
        reg.name=name
        gender=rgender
        mobile=phone
        print(f"'{name}' You have Registered Sucessfully")
        file.close()
        home()
        

    #login
    elif regstatus=='login':
        print("enter details to login:-")
        phone=int(input("Enter your phone no :"))
        password=input("Enter Password :")
        print()
        f = open("register.txt", "r")
        for i in f.readlines():
            d={}
            for j in i.split():
                s=j.split(":")
                d[s[0]]=s[1]
                
            if d['phone_no']==str(phone) and d['Password']==password:
                returning="true"
                name=d['name']
                gender=d['gender']
                break
            else:
                returning="false"
            
        if returning=="true":
            reg.name=name
            reg.phone=phone
            print(f"'{name}' You have Login Sucessfully")
            home()
        else:
            print("invalid login")
            reg()

    else:
        print("invalid input")
        reg()


def matches():
    print()
    interested=input("Enter the gender you are interested in m/f: ")
    print("Matches For You: \n")
    if interested=='m':
        f = open("register.txt", "r")
        for i in f.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]
                if d['gender']=='m':
                    print(f"NAME: {d['name']} , AGE: {d['age']} ")
                    like=input("Did you like him. Enter y/n: ")
                    if like=='y':
                        matches.matchname=d['name']
                        print("\u2764\ufe0f"+ f"{reg.name} & {d['name']} had a match  "+"\u2764\ufe0f")
                        store_matches()
                        home()
                        break
                    elif like=='n':
                        status="notfound"
                        
                    else:
                        print('Invalid input')
                        continue
        if status=="notfound":
            print()
            print('**MATCH NOT FOUND**')
            print()
            home()
        f.close()

    elif interested=='f':
        f = open("register.txt", "r")
        for i in f.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]
                if d['gender']=='f':
                    print(f"NAME: {d['name']} , AGE: {d['age']} ")
                    like=input("Did you like her. Enter y/n: ")
                    if like=='y':
                        matches.matchname=d['name']
                        print("\u2764\ufe0f"+ f"{reg.name} & {d['name']} had a match  "+"\u2764\ufe0f")
                        store_matches()
                        home()
                        break
                    elif like=='n':
                        status="notfound"
                    else:
                        print('Invalid input')
                        continue
        if status=="notfound":
            print()
            print('**MATCH NOT FOUND**')
            print()
            home()
        f.close()
        
    else:
        print("invalid input")
        matches()


def store_matches():
    from datetime import datetime
    user_name=reg.name
    match_name=matches.matchname
    date=datetime.date(datetime.now())
    file=open('matches.txt','a')
    match_details="user_name:"+user_name + " " +"match_name:" +match_name + " " +"date:" + str(date) + "\n"
    content=file.write(match_details)
    file.close()



def view_matches():
    print("Your all matches:- ")
    file=open("matches.txt",'r')
    view=file.readlines()
    
    for i in view:
        d={}
        
        for j in i.split():
            s=j.split(":")
            d[s[0]]=s[1]
        if reg.name==d['user_name']:
            print(f"{d['date']}: You and {d['match_name']} had a match" + "\u2764\ufe0f")
    home()
    file.close()
        
            
    

def home():
    print()
    home="HOME:"
    print(home.center(20))
    print("1. FIND YOUR MATCH. \n2. VIEW YOUR MATCHES. \n3. Logout. ")
    choice=input("Enter Your Choice '1/2/3': ")
    
    if choice=='1':
        print()
        matches()
    elif choice=='2':
        print()
        view_matches()
    elif choice=='3':
        print()
        reg()
    else:
        print("invalid input")
        print()
        home()



reg()




    
            
            
            
        

    


    


