import os
import gtts #pip install gTTS in cmd
from playsound import playsound #pip install playsound in cmd
from datetime import date
print("      Mpay \n Welcome to Mpay \n")


def play(text):
    file = "sound.mp3"
    tts = gtts.gTTS(text)
    tts.save(file) 
    playsound(file)
    os.remove(file)

play("Welcome to Mpay")

def reg():
    play("Enter 1 to register, enter 2 to login")
    regstatus=input("Enter Choice: \n 1.Register \n 2.Login \n Enter:")
    
    print()
    #registeration
    if regstatus=='1':
        print("enter registration details:-")
        play("enter registration details")
        fname=input("Enter your First Name to register :")
        lname=input("Enter your Last Name to register :")

        def checkage():
            rage=int(input("Enter your Age :"))
            checkage.age=rage
            if rage<18:
                print("*** Age Should Be Atleast 18 ***")
                checkage()
        
        checkage()  
        rgender=input("Enter your gender m/f :")
        
        def checkphone():
            phone=int(input("Enter your phone no :"))
            checkphone.phone=phone
            
            f = open("register.txt", "r")
            for i in f.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]

                if d['phone_no']==str(phone):
                    print("phone no already exist")
                    checkphone()
                    
                    

            if len(str(phone))<10 or len(str(phone))>10:
                print("**Invalid phone no**")
                print()
                checkphone()
                
            
            
        checkphone()
        phone=checkphone.phone
        age=checkage.age

        def check_password():
            password=input("Enter Password (alpha-numeric):")
            check_password.password=password
            a=""
            d=""
            for i in password:
                if i.isalpha()==True:
                    a="al"
                if i.isdigit()==True:
                    d="di"
            if a=='al' and d=='di':
                print("StrongPassword")
            else:
                print("Please enter alpha-numeric password")
                check_password()

        check_password()
        def upi():
            fourdigit=checkphone.phone
            fourdigit=str(fourdigit)
            upi.upi_id=fname+lname+fourdigit[6:10]+"@mpay"
            upi.acfourdigit=fourdigit[6:10]
        upi()
        todays_date = date.today()
        account_no="mpbk"+str(todays_date.year)+str(upi.acfourdigit)
        
        print()
        
        file=open('register.txt','a')
        details="fname:"+fname + " " + "lname:"+lname + " " + "age:" +str(age) + " " +"gender:" + rgender + " " + "phone_no:" + str(phone) + " "+ "account_no:" + account_no + " "+ "upi_id:" + upi.upi_id + " "+ "Password:" + check_password.password + "\n"
        content=file.write(details)
        reg.account_no=account_no
        reg.name=fname+" "+lname
        reg.phone=phone
        print(f"'{fname} {lname}' You have Registered Successfully")
        play(f"'{fname} {lname}' You have Registered successfully")
        file.close()
##        home()
        

    #login
    elif regstatus=='2':
        print("enter details to login:-")
        play("enter details to login")
        phone=int(input("Enter your phone no :"))
        password=input("Enter Password :")
        print()
        f = open("register.txt", "r")
        for i in f.readlines():
            d={}
            for j in i.split():
                s=j.split(":")
                d[s[0]]=s[1]
                
            if d['phone_no']==str(phone) and d['Password']==password:
                returning="true"
                name=d['fname']
                account_no=d['account_no']
                break
            else:
                returning="false"
            
        if returning=="true":
            reg.name=name
            reg.phone=phone
            reg.account_no=account_no
            print(f"'{name}' You have Login Successfully")
            play(f"'{name}' You have Login successfully")
##            home()
        else:
            print("invalid login")
            reg()

    else:
        print("invalid input")
        reg()



reg()



class Transactions:

    def check_balance(self):
         deposit=0
         withdraw=0
         paid=0
         received=0
         with open("Transactions.txt", "r") as read:
            for i in read.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]
                if d['account_no']==reg.account_no:
                    if d['status']=="deposited":
                        deposit=deposit+int(d['amt'])
                    if d['status']=="withdrawn":
                        withdraw=withdraw+int(d['amt'])
                    if d['status']=="paid":
                        paid=paid+int(d['amt'])
                if d['receiver']==str(reg.account_no):
                    received=received+int(d['amt'])
                if d['receiver']==str(reg.phone):
                    received=received+int(d['amt'])
            balance=deposit-withdraw-paid+received
            return balance

        


    def deposit(self):
        print("Deposit")
        amt=int(input("Enter the Total Amount of cash you want to deposit"))
        print("\n Enter Payement Details:- \n")
        rs2000=int(input("Enter no of rs.2000 notes "))*2000
        rs500=int(input("Enter no of rs.500 notes "))*500
        rs200=int(input("Enter no of rs.200 notes "))*200
        rs100=int(input("Enter no of rs.100 notes "))*100
        rs50=int(input("Enter no of rs.50 notes "))*50
        rs20=int(input("Enter no of rs.20 notes "))*20
        rs10=int(input("Enter no of rs.10 notes/coins "))*10
        rs5=int(input("Enter no of rs.5 notes/coins "))*5
        rs2=int(input("Enter no of rs.2 coins "))*2
        rs1=int(input("Enter no of rs.1 coins "))*1
        todays_date = date.today()
        total=rs2000+rs500+rs200+rs100+rs50+rs20+rs10+rs5+rs2+rs1
        if total==amt:
            with open("Transactions.txt",'a') as f:
                f.write(f"date:{todays_date} account_no:{reg.account_no} phone_no:{reg.phone} amt:{amt} status:deposited receiver:bank \n")
                print(f"₹{amt} is deposited to your Account ")
                play(f"₹{amt} is deposited to your Account ")
                obj1=Transactions()
                depositamt=obj1.check_balance()+amt
                print(f"Account Balance={depositamt}\n")
            home()

        else:
            print("Invalid Payement Details")
            play("Invalid Payement Details")
            deposit()



    def withdraw(self):
        print("Withdraw \n")
        amt=int(input("Enter the Amount of cash you want to Withdraw "))
        todays_date = date.today()
        obj1=Transactions()
        if obj1.check_balance()>=amt:
            fwithdraw=open("Transactions.txt",'a')
            fwithdraw.write(f"date:{todays_date} account_no:{reg.account_no} phone_no:{reg.phone} amt:{amt} status:withdrawn receiver:self \n")
            print(f"₹{amt} is Withdrawn from your Account ")
            play(f"₹{amt} is Withdrawn from your Account ")
            depositamt=obj1.check_balance()-amt
            print(f"Account Balance={depositamt}\n")
            fwithdraw.close()
            home()
                
        else:
            print("Insufficient Balance")
            print(f"Account Balance={obj1.check_balance()}")
            play(f"Insufficient Balance Your Account Balance is {obj1.check_balance()}")
            home()
        



    def send_money(self):
        print("Send Money \n")
        def check_ac_phone():
            receiver=input("Enter Phone no or Account no You want to transfer ")
            check_ac_phone.receiver=receiver
            with open("register.txt", "r") as read:
                for i in read.readlines():
                    d={}
                    notexist=""
                    for j in i.split():
                        s=j.split(":")
                        d[s[0]]=s[1]
                    if len(receiver)==12:
                        if d['account_no']==receiver:
                            print(f"Name: {d['fname']} {d['lname']}")
                            check_ac_phone.name=d['fname']+" "+d['lname']
                            notexist=""
                            break
                        elif d['account_no']!=receiver:
                            notexist="account"

                    elif len(receiver)==10:
                        if d['phone_no']==receiver:
                            print(f"Name: {d['fname']} {d['lname']}")
                            check_ac_phone.name=d['fname']+" "+d['lname']
                            notexist=""
                            break
                        elif d['phone_no']!=receiver:
                            notexist="phone"
                            
                    else:
                        print("Please enter valid account no or phone no")
                        check_ac_phone()

                if notexist=='account':
                    print("Account no does not exist")
                    check_ac_phone()
                elif notexist=='phone':
                    print("Phone no does not exist")
                    check_ac_phone()
                        
                    
        check_ac_phone()        
        amt=int(input("Enter the Amount of cash you want to Transfer "))
        todays_date = date.today()
        obj1=Transactions()
        if obj1.check_balance()>=amt:
            fsend=open("Transactions.txt",'a')
            fsend.write(f"date:{todays_date} account_no:{reg.account_no} phone_no:{reg.phone} amt:{amt} status:paid receiver:{check_ac_phone.receiver} \n")
            print(f"₹{amt} is sent to {check_ac_phone.name} from your Account ")
            play(f"₹{amt} is sent to {check_ac_phone.name} from your Account ")
            depositamt=obj1.check_balance()-amt
            print(f"Account Balance={depositamt}\n")
            fsend.close()
            home()
                
        else:
            print("Insufficient Balance")
            print(f"Account Balance={obj1.check_balance()}")
            play(f"Insufficient Balance Your Account Balance is {obj1.check_balance()}")
            home()
        

    def view_transactions(self):
        print("Your Transactions:-")
        with open("Transactions.txt", "r") as read:
            for i in read.readlines():
                d={}
                for j in i.split():
                    s=j.split(":")
                    d[s[0]]=s[1]
                if d['account_no']==reg.account_no:
                    if d['status']=="deposited":
                        print("Date",d['date'],"To",d['account_no'],"Amt=",d['amt'],"Deposited")
                    if d['status']=="withdrawn":
                        print("Date",d['date'],"From",d['account_no'],"Amt=",d['amt'],"Withdrawn")
                    if d['status']=="paid":
                        print("Date",d['date'],"To",d['receiver'],"Amt=",d['amt'],"Paid")
                if d['receiver']==str(reg.account_no):
                        print("Date",d['date'],"From",d['receiver'],"Amt=",d['amt'],"Received")
                if d['receiver']==str(reg.phone):
                        print("Date",d['date'],"From",d['receiver'],"Amt=",d['amt'],"Received")
            obj1=Transactions()
            print("Account Balance=",obj1.check_balance())
            home()
    
    
def home():
    print("\n HOME \n")
    play("Enter Your Choice")
    print("Enter:- \n 1.Deposit \n 2.Withdraw \n 3.Send Money \n 4.Check Balance \n 5.View Transactions \n 6.Logout ")
    choice=int(input("Enter Choice"))
    obj1=Transactions()
    if choice==1:
        play("Enter Details To Deposit")
        obj1.deposit()
    elif choice==2:
        play("Enter Details To Withdraw")
        obj1.withdraw()
    elif choice==3:
        play("Enter Details To Send Money")
        obj1.send_money()
    elif choice==4:
        play("Your Account Balance is "+str(obj1.check_balance()))
        print("\n Your Account Balance = "+str(obj1.check_balance())+"\n")
        home()
    elif choice==5:
        play("Your Transactions Are as follows")
        obj1.view_transactions()
    elif choice==6:
        play("logging out")
        reg()
    else:
        play("Invalid Choice")
        print("** Invalid Choice **")
            
    

home()   


    


